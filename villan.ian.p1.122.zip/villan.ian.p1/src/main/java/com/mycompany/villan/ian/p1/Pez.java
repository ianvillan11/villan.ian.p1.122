package com.mycompany.villan.ian.p1;


public class Pez extends Especie implements Nadador{
    private double longitudMaxima;
    
    public Pez(String nombre,String habitat,TipoAgua tipoAgua,double longitudMaxima){
        super(nombre,habitat,tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }
    
    public double getLongitudMaxima(){
        return longitudMaxima;
    }
    

    @Override
    public void nadar(){
        System.out.println(getNombre() + " nada rapidamente en su habitat");
    }
    
    @Override
    public String toString(){
        return super.toString() + ",longitudMaxima = " + longitudMaxima + "cm";
    }
}
