package com.mycompany.villan.ian.p1;

public abstract class Especie {
    private String nombre;
    private String habitat;
    private TipoAgua tipoAgua;
    
    public Especie(String nombre,String habitat,TipoAgua tipoAgua){
        this.nombre = nombre;
        this.habitat = habitat;
        this.tipoAgua = tipoAgua;
        
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getHabitat(){
        return habitat;
    }
    
    public TipoAgua getTipoAgua(){
        return tipoAgua;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre: ");
        sb.append(nombre);
        sb.append(",Hábitat: ");
        sb.append(habitat);
        sb.append(",Tipo de agua: ");
        sb.append(tipoAgua);
        return sb.toString();
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == null || o.getClass() != this.getClass()) return false;

        Especie e = (Especie) o;
        return e.getNombre().equals(this.nombre) && e.getHabitat().equals(this.habitat);
    }
    
    
    
    

    

}
