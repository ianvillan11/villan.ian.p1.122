package com.mycompany.villan.ian.p1;

public class Crustaceo extends Especie implements BuscadorAlimento{
    private int numeroPatas;
    
    public Crustaceo(String nombre,String habitat,TipoAgua tipoAgua,int numeroPatas){
        super(nombre,habitat,tipoAgua);
        this.numeroPatas = numeroPatas;
    }
    
    public int getNumeroPatas() {
        return numeroPatas;
    }
    
    @Override
    public String toString(){
        return super.toString() + " Numero de patas: " + numeroPatas;
    }
    
    @Override
    public void buscarAlimento() {
        System.out.println(getNombre() + " busca alimentos rapidamente");
    }

    
}
