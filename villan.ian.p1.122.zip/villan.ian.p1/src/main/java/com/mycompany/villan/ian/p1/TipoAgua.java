
package com.mycompany.villan.ian.p1;


public enum TipoAgua {
    AGUA_DULCE,
    AGUA_SALADA
}
