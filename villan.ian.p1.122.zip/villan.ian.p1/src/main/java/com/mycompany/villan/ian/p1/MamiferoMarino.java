package com.mycompany.villan.ian.p1;

public class MamiferoMarino extends Especie implements Nadador,BuscadorAlimento{
    private int frecuenciaRespiracion;
    
    public MamiferoMarino(String nombre,String habitat,TipoAgua tipoAgua, int frecuenciaRespirando){
        super(nombre,habitat,tipoAgua);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }
    
    public int getFrecuenciaRespiracion(){
        return frecuenciaRespiracion;
    }
    
    
    public String toString() {
       return super.toString() + " Frecuencia de respiración: " + frecuenciaRespiracion;
    }
    
    @Override
    public void buscarAlimento(){
        System.out.println(getNombre() + " se alimenta en el océano");
    }
   
    @Override
    public void nadar(){
        System.out.println(getNombre() + " nada por un tiempo y sale del agua a recuperar oxigeno");
    }
    
}
