

package com.mycompany.villan.ian.p1;


public class VillanIanP1 {

    public static void main(String[] args) {
        Acuario acuario = new Acuario();
        
        
        try {
            

            Especie pez1 = new Pez("Nemo", "Estanque", TipoAgua.AGUA_SALADA , 15);
            Especie pez2 = new Pez("Nemo", "Arrecife", TipoAgua.AGUA_SALADA ,20);
            Especie pez3 = new Pez("Julio", "Coral", TipoAgua.AGUA_SALADA, 20);
            
            MamiferoMarino delfin = new MamiferoMarino("Doroti", "Oceano", TipoAgua.AGUA_SALADA, 12);
            Crustaceo cangrejo = new Crustaceo("Crabby", "Playa", TipoAgua.AGUA_SALADA, 8);
            
            
            acuario.agregarEspecie(delfin);
            acuario.agregarEspecie(cangrejo);
            acuario.agregarEspecie(pez1);
            acuario.agregarEspecie(pez2);
            acuario.agregarEspecie(pez3);

        } catch (EspecieDuplicadaException e) {
            System.out.println("Error:" + e.getMessage());
        }
        
        System.out.println("\nEspecies registradas");
        acuario.mostrarAnimales();
        
        
        System.out.println("\nEspecies nadando:");
        acuario.TestNado();

        System.out.println("\nEspecies buscando alimento: ");
        acuario.TestBuscarAlimento();
        
 
        acuario.filtrarPorTipoAgua(TipoAgua.AGUA_SALADA);

        acuario.filtrarPorTipoAgua(TipoAgua.AGUA_DULCE);
        
        
        acuario.mostrarAnimalesPorTipo("Pez");

        acuario.mostrarAnimalesPorTipo("MamiferoMarino");

        acuario.mostrarAnimalesPorTipo("Crustaceo");
        
    }
    
    
    
}
