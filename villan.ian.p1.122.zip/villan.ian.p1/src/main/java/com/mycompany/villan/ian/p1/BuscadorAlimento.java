
package com.mycompany.villan.ian.p1;


public interface BuscadorAlimento {
    void buscarAlimento();
    
}
