package com.mycompany.villan.ian.p1;

import java.util.ArrayList;
import java.util.List;


public class Acuario {
    
    private List<Especie> especies;

    public Acuario() {
        especies = new ArrayList<>();
    }

    public void agregarEspecie(Especie especie) throws EspecieDuplicadaException {
        for (Especie e : especies) {
            if (e.equals(especie)) {
                throw new EspecieDuplicadaException("Ya existe una especie con el nombre " + especie.getNombre() +" y hábitat " + especie.getHabitat());
                
            }
        }
        especies.add(especie);
        System.out.println("La especie se ingreso con exito");
    }
    
    
    public void mostrarAnimales(){
        if(especies.isEmpty()){
            System.out.println("No hay ninguna especie registrada");
            return;
        }
        
        for(Especie e : especies){
            System.out.println(e.toString());
            
            
        }
        
        
    }
    
    public void TestNado(){
        for (Especie e : especies){
            if (e instanceof Nadador n){
                n.nadar();
            }else{
                System.out.println(e.getNombre() + ",esta especie no puede nadar");
            }
        }
    }
    
    public void TestBuscarAlimento(){
        for (Especie e : especies){
            if(e instanceof BuscadorAlimento b){
                b.buscarAlimento();
            }else{
                System.out.println(e.getNombre() + ",esta especie no puede buscar alimento");
            }
        }
    }
    
    public void filtrarPorTipoAgua(TipoAgua tipo) {
        boolean hayAnimales = false;
        String tipoTexto;

        if (tipo == TipoAgua.AGUA_DULCE) {
            tipoTexto = "dulce";
        } else {
            tipoTexto = "salada";
        }

        System.out.println("\n Especies que viven en agua " + tipoTexto + ":");

        for (Especie e : especies) {
            if (e.getTipoAgua() == tipo) {
                System.out.println(e.toString());
                hayAnimales = true;
            }
        }

        if (!hayAnimales) {
            System.out.println("No hay ninguna especies registradas en este tipo de agua");
        }
    }
    
    public void mostrarAnimalesPorTipo(String tipoEspecies) {
    boolean hayEspecies = false;

    System.out.println("\nAnimales del tipo: " + tipoEspecies);

    for (Especie e : especies) {
        // Comprobar el tipo según el nombre de la clase
        if (tipoEspecies.equalsIgnoreCase("Pez") && e instanceof Pez) {
            System.out.println(e.toString());
            hayEspecies = true;
        } else if (tipoEspecies.equalsIgnoreCase("MamiferoMarino") && e instanceof MamiferoMarino) {
            System.out.println(e.toString());
            hayEspecies = true;
        } else if (tipoEspecies.equalsIgnoreCase("Crustaceo") && e instanceof Crustaceo) {
            System.out.println(e.toString());
            hayEspecies = true;
        }
    }

    if (!hayEspecies) {
        System.out.println("No hay ninguna especie registradas de este tipo");
    }
}
    
    
    
    
    
    
}
