package com.mycompany.villan.ian.p1;


public class EspecieDuplicadaException extends Exception{
    private static final String MENSAJE = "Error,Ya hay una especie con el mismo nombre y habitat";
    
    public EspecieDuplicadaException(){
        this(MENSAJE);
    }
    
    public EspecieDuplicadaException(String mensaje){
        super(mensaje);
    }
}


